Python Basics with Numpy (Numpy Python Tutorial)
