Build a logistic regression model in python from scratch.
Interpret logistic regression model as a neural network.
